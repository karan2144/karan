# Message Search Bot

We have to use Bot for Inline Search & Userbot for Searching in Channels. So both Bot & Userbot will work together.

## Installation

<details><summary><b>Deploy to Heroku</b></summary>
<p>
<br>
<a href="https://heroku.com/deploy?template=https://github.com/CyniteOfficial/MdiskSearchBotV2">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
</a>
</p>
</details>

<details>
  <summary><b>Deploy to Railway</b></summary>
<br/>

<p align="left">
<a href="https://railway.app/deploy?template=https://github.com/CyniteOfficial/MdiskSearchBotV2"
">
     <img height="30px" src="https://railway.app/button.svg">
  </a>
</p>
</details>
